import org.testng.annotations.Test;

public class Personal {
	@Test
	public void display() {
		System.out.println("Personal Loan method1");
	}
	
	@Test
	public void display2() {
		System.out.println("Personal Loan method2");
	}
}
