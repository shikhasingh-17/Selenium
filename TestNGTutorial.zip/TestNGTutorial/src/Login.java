import org.testng.annotations.Test;

public class Login {
	
	@Test
	public void MobileLogin() {
		System.out.println("This is Mobile Login method");
	}
	
	@Test
	public void WebLogin() {
		System.out.println("This is Web Login method");
	}

	@Test
	public void APILogin() {
		System.out.println("This is API Login method");
	}

}
