import org.testng.annotations.Test;

public class Car2 {
	
	@Test
	public void display() {
		System.out.println("Car Loan Application Class 2");
	}

}
