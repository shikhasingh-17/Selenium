import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TC003_FacebookXPATH {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//create webdriver object
				System.setProperty("webdriver.chrome.driver", "C:\\Users\\zvxs5t\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
				WebDriver driver = new ChromeDriver();
				
				//invoke browser and navigate to Gmail.com
				driver.get("https://www.facebook.com/");
				System.out.println(driver.getTitle());
				
				//enter username, password, click Login button using customised xPath
				//syntax "//tagname[@attribute='value']"
				/*driver.findElement(By.xpath("//input[@id='email']")).sendKeys("Shikha");
				driver.findElement(By.xpath("//input[@name='pass']")).sendKeys("Shikha");
				driver.findElement(By.xpath("//*[@value='Log In']")).click();*/
				
				
				//enter username, password, click Login button using customised CSS Selector
				//syntax "tagname[attribute='value']" or "[attribute='value']"
				driver.findElement(By.cssSelector("input[type='email']")).sendKeys("hello");
				driver.findElement(By.cssSelector("input[name='pass']")).sendKeys("hello");
				driver.findElement(By.cssSelector("input[value='Log In']")).click();
				
				
				//print error msg
				System.out.println(driver.getTitle());

	}

}
