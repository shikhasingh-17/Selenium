import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TC001_GmailLogin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//create webdriver object
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\zvxs5t\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		//invoke browser and navigate to Gmail.com
		driver.get("https://gmail.com");
		System.out.println(driver.getTitle());
		
		//locate the email id editbox
		driver.findElement(By.id("identifierId")).sendKeys("dummyEmail@gmail.com");
		driver.findElement(By.linkText("https://support.google.com/accounts?p=signin_privatebrowsing&hl=en-GB")).click();
		

	}

}
