import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TC002_salesforce {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//create webdriver object
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\zvxs5t\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		//invoke browser and navigate to Gmail.com
		driver.get("https://login.salesforce.com");
		System.out.println(driver.getTitle());
		
		//enter username, password, click Login button.
		driver.findElement(By.id("username")).sendKeys("hello");
		driver.findElement(By.id("password")).sendKeys("world");
		driver.findElement(By.id("Login")).click();
		
		//print error msg
		System.out.println(driver.findElement(By.cssSelector("div#error.loginError")).getText());
		
	
		
		
	}

}
